package com.example.nishanthkumarg.myapplication;

import com.example.nishanthkumarg.myapplication.lintpackage.Lintcheck;

/**
 * Created by nishanthkumarg on 11/3/16.
 */

public class MyClass {

    TestRestrClass  tcls = new TestRestrClass();

    MyClass(){
        tcls.sampleFunction();
    }
}
