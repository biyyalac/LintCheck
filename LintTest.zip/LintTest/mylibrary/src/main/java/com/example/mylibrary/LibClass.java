package com.example.mylibrary;

import android.support.annotation.RestrictTo;

import static android.support.annotation.RestrictTo.Scope.GROUP_ID;

/**
 * Created by nishanthkumarg on 11/2/16.
 */
@RestrictTo(GROUP_ID)
public class LibClass {

    public void function(){

    }
}
