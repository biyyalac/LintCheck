package com.example.navigationeditor5

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.navigation.fragment.findNavController
import com.example.navigationeditor5.databinding.FragmentFirstBinding
import kotlin.random.Random

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.buttonFirst.setOnClickListener {
            click()
          //  findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }


    fun click()
    {
        val name = requireView().findViewById<EditText>(R.id.name);
        val age = requireView().findViewById<EditText>(R.id.age)
        val user = UserInfo(Random.nextInt(0, 100),name.text.toString(), age.text.toString().toInt())
       val b=Bundle()
        b.putSerializable("user",user)
        findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment,b)
        //val directions = FirstFragmentDirections.actionFirstFragmentToSecondFragment(user)
    }
}