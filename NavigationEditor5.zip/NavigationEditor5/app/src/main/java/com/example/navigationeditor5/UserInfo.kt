package com.example.navigationeditor5

import java.io.Serializable

class UserInfo(val id:Int, val name: String, val age:Int): Serializable {
    val description: String
        get() = "$name is $age years old, with id as $id."
}